# M3FD custom object-detection split

This directory provides the fixed custom M3FD partition used in this study. Since M3FD does not provide an official train/validation/test partition, the 4,200 paired infrared-visible images were divided at the paired-image level into **3,360 training pairs, 420 validation pairs, and 420 test pairs** using random seed `42`.

This is a deterministic, class-aware partition specific to the present study. It is not claimed to reproduce any unpublished frame assignment from previous work.

## Included files

- `train.txt`, `val.txt`, and `test.txt`: frame IDs assigned to the training, validation, and test subsets.
- `split_manifest.csv`: split assignments for all 4,200 frame IDs.
- `split_report.json`: split sizes, random seed, class definitions, class-instance counts, and construction metadata.

The original M3FD images and annotations are not redistributed in this supplementary package. Users should obtain the dataset separately and apply the provided frame-ID lists.

## Evaluated classes

| Target ID | Class | Source M3FD IDs |
| --- | --- | --- |
| 0 | person | 0 (People) |
| 1 | car | 1 (Car) |
| 2 | other_vehicle | 2 (Bus) + 5 (Truck) |

The source `Motorcycle` (3) and `Lamp` (4) annotations are removed. Images are retained even if no evaluated-class annotation remains because they remain valid negative samples for the three-class detector.

## Internal comparability

All M3FD methods reported in this study were trained and evaluated using exactly these fixed split lists. Consequently, the reported M3FD results are internally comparable within the study protocol only and should not be directly compared with results obtained using different M3FD partitions.
